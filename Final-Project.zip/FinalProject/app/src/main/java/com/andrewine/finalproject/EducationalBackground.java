package com.andrewine.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class EducationalBackground extends AppCompatActivity {

    RadioGroup EducAttainment;
    RadioButton EducAttainmentSelected;
    TextView Elem, Sec, Voc, Col, Grad;
    EditText TxtElemNoS, TxtElemBE;
    EditText TxtSecondNoS, TxtSecondBE;
    EditText TxtVocNoS, TxtVocBE;
    EditText TxtColNoS, TxtColBE;
    EditText TxtGradNoS, TxtGradBE;
    Button BtnNext;
    Uri imageUri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_educational_background);

        EducAttainment = findViewById(R.id.ed_educAttainment_radioGroup);
        Elem = findViewById(R.id.textView3);
        Sec= findViewById(R.id.textView4eb);
        Voc = findViewById(R.id.textView5eb);
        Col = findViewById(R.id.textView6);
        Grad = findViewById(R.id.textView7);
        TxtElemNoS = findViewById(R.id.eb_Elem_NoS);
        TxtElemBE = findViewById(R.id.eb_Elem_BE);
        TxtSecondNoS = findViewById(R.id.eb_Secondary_NoS);
        TxtSecondBE = findViewById(R.id.eb_Secondary_BE);
        TxtVocNoS = findViewById(R.id.eb_Vocational_NoS);
        TxtVocBE = findViewById(R.id.eb_Vocational_BE);
        TxtColNoS = findViewById(R.id.eb_College_NoS);
        TxtColBE = findViewById(R.id.eb_College_BE);
        TxtGradNoS = findViewById(R.id.eb_Graduate_NoS);
        TxtGradBE = findViewById(R.id.eb_Gradaute_BE);
        BtnNext = findViewById(R.id.eb_next);

        BtnNext.setOnClickListener(view -> {

            if (EducAttainment.getCheckedRadioButtonId() == -1) {
                Toast.makeText(this, "Please select educational attainment", Toast.LENGTH_SHORT).show();
            } else {
                boolean isAnyFieldEmpty = false;

                switch (EducAttainmentSelected.getText().toString()) {
                    case "Elementary":
                        isAnyFieldEmpty = isAnyFieldEmpty(TxtElemNoS, TxtElemBE);
                        break;
                    case "Secondary":
                        isAnyFieldEmpty = isAnyFieldEmpty(TxtElemNoS, TxtElemBE, TxtSecondNoS, TxtSecondBE);
                        break;
                    case "Vocational":
                        isAnyFieldEmpty = isAnyFieldEmpty(TxtElemNoS, TxtElemBE, TxtSecondNoS, TxtSecondBE, TxtVocNoS, TxtVocBE);
                        break;
                    case "College":
                        isAnyFieldEmpty = isAnyFieldEmpty(TxtElemNoS, TxtElemBE, TxtSecondNoS, TxtSecondBE, TxtVocNoS, TxtVocBE, TxtColNoS, TxtColBE);
                        break;
                    case "Graduate Studies":
                        isAnyFieldEmpty = isAnyFieldEmpty(TxtElemNoS, TxtElemBE, TxtSecondNoS, TxtSecondBE, TxtVocNoS, TxtVocBE, TxtColNoS, TxtColBE, TxtGradNoS, TxtGradBE);
                        break;
                }

                if (isAnyFieldEmpty) {
                    Toast.makeText(this, "Please fill in the the Required Fields", Toast.LENGTH_SHORT).show();
                } else {
                    Intent personalBackground = getIntent();
//
                    String firstname = personalBackground.getStringExtra("PBfirstname");
                    String lastname = personalBackground.getStringExtra("PBlastname");
                    String email = personalBackground.getStringExtra("PBemail");
                    String gender = personalBackground.getStringExtra("PBgender");
                    String phone = personalBackground.getStringExtra("PBphone");
                    String height = personalBackground.getStringExtra("PBheight");
                    String weight = personalBackground.getStringExtra("PBweight");
                    String civilStatus = personalBackground.getStringExtra("PBcivilStatus");
                    String name = personalBackground.getStringExtra("PBname");
                    String contact = personalBackground.getStringExtra("PBcontact");
                    String pagibig = personalBackground.getStringExtra("PBpagibig");
                    String tin = personalBackground.getStringExtra("PBtin");
                    String philhealth = personalBackground.getStringExtra("PBphilhealth");
                    String gsis = personalBackground.getStringExtra("PBgsis");
                    String relationships = personalBackground.getStringExtra("PBrelationships");

                    String imageUriString = personalBackground.getStringExtra("PBimageUri");
                    if (imageUriString != null) {
                        imageUri = Uri.parse(imageUriString);
                    }

                    String elemSchool = TxtElemNoS.getText().toString();
                    String elemCourse = TxtElemBE.getText().toString();
                    String secSchool = TxtSecondNoS.getText().toString();
                    String secCourse = TxtSecondBE.getText().toString();
                    String vocSchool = TxtVocNoS.getText().toString();
                    String vocCourse = TxtVocBE.getText().toString();
                    String colSchool = TxtColNoS.getText().toString();
                    String colCourse = TxtColBE.getText().toString();
                    String gradSchool = TxtGradNoS.getText().toString();
                    String gradCourse = TxtGradBE.getText().toString();

                    Intent EducationalBackground = new Intent(this, CriminalBackground.class);

                    EducationalBackground.putExtra("PBfirstname", firstname);
                    EducationalBackground.putExtra("PBlastname", lastname);
                    EducationalBackground.putExtra("PBemail", email);
                    EducationalBackground.putExtra("PBgender", gender);
                    EducationalBackground.putExtra("PBphone", phone);
                    EducationalBackground.putExtra("PBheight", height);
                    EducationalBackground.putExtra("PBweight", weight);
                    EducationalBackground.putExtra("PBcivilStatus", civilStatus);
                    EducationalBackground.putExtra("PBname", name);
                    EducationalBackground.putExtra("PBcontact", contact);
                    EducationalBackground.putExtra("PBpagibig", pagibig);
                    EducationalBackground.putExtra("PBtin", tin);
                    EducationalBackground.putExtra("PBphilhealth", philhealth);
                    EducationalBackground.putExtra("PBgsis", gsis);
                    EducationalBackground.putExtra("PBrelationships", relationships);

                    EducationalBackground.putExtra("EBelemNoS", !elemSchool.isEmpty() ? elemSchool : "N/A");
                    EducationalBackground.putExtra("EBelemBE", !elemCourse.isEmpty() ? elemCourse : "N/A");
                    EducationalBackground.putExtra("EBsecNoS", !secSchool.isEmpty() ? secSchool : "N/A");
                    EducationalBackground.putExtra("EBsecBE", !secCourse.isEmpty() ? secCourse : "N/A");
                    EducationalBackground.putExtra("EBvocNoS", !vocSchool.isEmpty() ? vocSchool : "N/A");
                    EducationalBackground.putExtra("EBvocBE", !vocCourse.isEmpty() ? vocCourse : "N/A");
                    EducationalBackground.putExtra("EBcolNoS", !colSchool.isEmpty() ? colSchool : "N/A");
                    EducationalBackground.putExtra("EBcolBE", !colCourse.isEmpty() ? colCourse : "N/A");
                    EducationalBackground.putExtra("EBgradNoS", !gradSchool.isEmpty() ? gradSchool : "N/A");
                    EducationalBackground.putExtra("EBgradBE", !gradCourse.isEmpty() ? gradCourse : "N/A");

                    EducationalBackground.putExtra("PBimageUri", imageUri.toString());

                    startActivity(EducationalBackground);
                }
            }
        });

    }

    public void checkEducAttainment(View v){
        int radioId = EducAttainment.getCheckedRadioButtonId();
        EducAttainmentSelected = findViewById(radioId);

        if (EducAttainmentSelected.getText().toString().equals("Elementary")) {
            Elem.setVisibility(View.VISIBLE);
            Sec.setVisibility(View.GONE);
            Voc.setVisibility(View.GONE);
            Col.setVisibility(View.GONE);
            Grad.setVisibility(View.GONE);
            TxtElemNoS.setVisibility(View.VISIBLE);
            TxtElemBE.setVisibility(View.VISIBLE);
            TxtSecondNoS.setVisibility(View.GONE);
            TxtSecondBE.setVisibility(View.GONE);
            TxtVocNoS.setVisibility(View.GONE);
            TxtVocBE.setVisibility(View.GONE);
            TxtColNoS.setVisibility(View.GONE);
            TxtColBE.setVisibility(View.GONE);
            TxtGradNoS.setVisibility(View.GONE);
            TxtGradBE.setVisibility(View.GONE);
        } else if (EducAttainmentSelected.getText().toString().equals("Secondary")) {
            Elem.setVisibility(View.VISIBLE);
            Sec.setVisibility(View.VISIBLE);
            Voc.setVisibility(View.GONE);
            Col.setVisibility(View.GONE);
            Grad.setVisibility(View.GONE);
            TxtElemNoS.setVisibility(View.VISIBLE);
            TxtElemBE.setVisibility(View.VISIBLE);
            TxtSecondNoS.setVisibility(View.VISIBLE);
            TxtSecondBE.setVisibility(View.VISIBLE);
            TxtVocNoS.setVisibility(View.GONE);
            TxtVocBE.setVisibility(View.GONE);
            TxtColNoS.setVisibility(View.GONE);
            TxtColBE.setVisibility(View.GONE);
            TxtGradNoS.setVisibility(View.GONE);
            TxtGradBE.setVisibility(View.GONE);
        } else if (EducAttainmentSelected.getText().toString().equals("Vocational")) {
            Elem.setVisibility(View.VISIBLE);
            Sec.setVisibility(View.VISIBLE);
            Voc.setVisibility(View.VISIBLE);
            Col.setVisibility(View.GONE);
            Grad.setVisibility(View.GONE);
            TxtElemNoS.setVisibility(View.VISIBLE);
            TxtElemBE.setVisibility(View.VISIBLE);
            TxtSecondNoS.setVisibility(View.VISIBLE);
            TxtSecondBE.setVisibility(View.VISIBLE);
            TxtVocNoS.setVisibility(View.VISIBLE);
            TxtVocBE.setVisibility(View.VISIBLE);
            TxtColNoS.setVisibility(View.GONE);
            TxtColBE.setVisibility(View.GONE);
            TxtGradNoS.setVisibility(View.GONE);
            TxtGradBE.setVisibility(View.GONE);
        } else if (EducAttainmentSelected.getText().toString().equals("College")) {
            Elem.setVisibility(View.VISIBLE);
            Sec.setVisibility(View.VISIBLE);
            Voc.setVisibility(View.VISIBLE);
            Col.setVisibility(View.VISIBLE);
            Grad.setVisibility(View.GONE);
            TxtElemNoS.setVisibility(View.VISIBLE);
            TxtElemBE.setVisibility(View.VISIBLE);
            TxtSecondNoS.setVisibility(View.VISIBLE);
            TxtSecondBE.setVisibility(View.VISIBLE);
            TxtVocNoS.setVisibility(View.VISIBLE);
            TxtVocBE.setVisibility(View.VISIBLE);
            TxtColNoS.setVisibility(View.VISIBLE);
            TxtColBE.setVisibility(View.VISIBLE);
            TxtGradNoS.setVisibility(View.GONE);
            TxtGradBE.setVisibility(View.GONE);
        } else if (EducAttainmentSelected.getText().toString().equals("Graduate Studies")) {
            Elem.setVisibility(View.VISIBLE);
            Sec.setVisibility(View.VISIBLE);
            Voc.setVisibility(View.VISIBLE);
            Col.setVisibility(View.VISIBLE);
            Grad.setVisibility(View.VISIBLE);
            TxtElemNoS.setVisibility(View.VISIBLE);
            TxtElemBE.setVisibility(View.VISIBLE);
            TxtSecondNoS.setVisibility(View.VISIBLE);
            TxtSecondBE.setVisibility(View.VISIBLE);
            TxtVocNoS.setVisibility(View.VISIBLE);
            TxtVocBE.setVisibility(View.VISIBLE);
            TxtColNoS.setVisibility(View.VISIBLE);
            TxtColBE.setVisibility(View.VISIBLE);
            TxtGradNoS.setVisibility(View.VISIBLE);
            TxtGradBE.setVisibility(View.VISIBLE);
        }
    }

    private boolean isAnyFieldEmpty(EditText... editTexts) {
        for (EditText editText : editTexts) {
            if (editText.getText().toString().isEmpty()){
                return true;
            }
        }
        return false;
    }

}